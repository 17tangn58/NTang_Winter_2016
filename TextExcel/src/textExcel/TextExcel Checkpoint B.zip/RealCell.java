package textExcel;

public abstract class RealCell implements Cell {
	private String input;
	public RealCell(String value){
		input=value;
	}
	@Override
	public String abbreviatedCellText() {
		// TODO Auto-generated method stub
		return "";
	}
	public String getString(){
		return input;
	}
	@Override
	public String fullCellText() {
		// TODO Auto-generated method stub
		return input;
	}
	public double getDoubleValue(){
		return 0.0;
	}

}
